export const GENRE_OPTIONS = [
    { value: "Action", label: "Action" },
    { value: "Drama", label: "Drama" },
    { value: "Sci-Fi", label: "Sci-Fi" },
    { value: "Romance", label: "Romance" },
  ];