import { Modal } from "antd";
import React from "react";

const ModalMovieDelete = ({ title, visible, onCancel, onSuccess, loading }) => {
  return (
    <Modal
      title="Delete Movie"
      open={visible}
      onCancel={onCancel}
      onOk={onSuccess}
      okText="Delete"
      okButtonProps={{ danger: true }}
      cancelText="Cancel"
      confirmLoading={loading}
      width={500}
    >
      <p className="mt-5">
        Are you sure you want to delete the movie <br></br> <strong className="text-lg">{title}</strong>{" "}
      </p>
      <p>This action cannot be undone.</p>
    </Modal>
  );
};

export default ModalMovieDelete;
