import React from 'react';

const ErrorPage = () => {
    return (
        <div>
            <h1>404 Error</h1>
        </div>
    );
}

export default ErrorPage;
