import React from 'react';

const Cinemas = () => {
    return (
        <div>
            <h1>Cinemas</h1>
        </div>
    );
}

export default Cinemas;
