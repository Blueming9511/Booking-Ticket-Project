import React from 'react'
import DynamicTable from '../../components/ui/DynamicTable'
import { Image } from 'antd'

const columns = [
  {
    title: 'Thumbnail',
    dataIndex: 'thumbnail',
    key: 'thumbnail',
    render: src => <Image width={50} src={src} />
  },
  { title: 'Title', dataIndex: 'title', key: 'title' },
  { title: 'Genre', dataIndex: 'genre', key: 'genre' },
  { title: 'Director', dataIndex: 'director', key: 'director' },
  { title: 'Duration', dataIndex: 'duration', key: 'duration' },
  { title: 'Box Office', dataIndex: 'boxOffice', key: 'boxOffice' },
  { title: 'Release Year', dataIndex: 'releaseYear', key: 'releaseYear' },
  { title: 'Rating', dataIndex: 'rating', key: 'rating' }
]

const initData = [
  {
    key: '1',
    thumbnail:
      'https://image.tmdb.org/t/p/w200/kyeqWdyUXW608qlYkRqosgbbJyK.jpg',
    title: 'Avatar',
    genre: 'Sci-Fi',
    releaseYear: '2009',
    director: 'James Cameron',
    rating: '7.8',
    duration: '162',
    language: 'English',
    budget: '$237M',
    boxOffice: '$2.923B',
    casts: ['Sam Worthington', 'Zoe Saldana', 'Sigourney Weaver'],
    releasedBy: 'CGV',
    releaseDate: '2009-12-18',
    endDate: '2010-03-15'
  },
  {
    key: '2',
    thumbnail:
      'https://image.tmdb.org/t/p/w200/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg',
    title: 'Titanic',
    genre: 'Romance',
    releaseYear: '1997',
    director: 'James Cameron',
    rating: '7.9',
    duration: '195',
    language: 'English',
    budget: '$200M',
    boxOffice: '$2.202B',
    casts: ['Leonardo DiCaprio', 'Kate Winslet', 'Billy Zane'],
    releasedBy: 'Cinestar',
    releaseDate: '1997-12-19',
    endDate: '1998-04-20'
  },
  {
    key: '3',
    thumbnail:
      'https://image.tmdb.org/t/p/w200/or06FN3Dka5tukK1e9sl16pB3iy.jpg',
    title: 'Avengers: Endgame',
    genre: 'Action',
    releaseYear: '2019',
    director: 'Anthony & Joe Russo',
    rating: '8.4',
    duration: '181',
    language: 'English',
    budget: '$356M',
    boxOffice: '$2.798B',
    casts: ['Robert Downey Jr.', 'Chris Evans', 'Scarlett Johansson'],
    releasedBy: 'BHD',
    releaseDate: '2019-04-26',
    endDate: '2019-09-10'
  },
  {
    key: '4',
    thumbnail:
      'https://image.tmdb.org/t/p/w200/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg',
    title: 'Joker',
    genre: 'Drama',
    releaseYear: '2019',
    director: 'Todd Phillips',
    rating: '8.4',
    duration: '122',
    language: 'English',
    budget: '$55M',
    boxOffice: '$1.074B',
    casts: ['Joaquin Phoenix', 'Robert De Niro', 'Zazie Beetz'],
    releasedBy: 'Lotte Cinema',
    releaseDate: '2019-10-04',
    endDate: '2020-01-15'
  },
  {
    key: '5',
    thumbnail:
      'https://image.tmdb.org/t/p/w200/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg',
    title: 'The Shawshank Redemption',
    genre: 'Drama',
    releaseYear: '1994',
    director: 'Frank Darabont',
    rating: '9.3',
    duration: '142',
    language: 'English',
    budget: '$25M',
    boxOffice: '$73.3M',
    casts: ['Tim Robbins', 'Morgan Freeman', 'Bob Gunton'],
    releasedBy: 'Galaxy Cinema',
    releaseDate: '1994-09-23',
    endDate: '1995-01-10'
  }
]

const Movies = () => {
  return (
    <div>
      <DynamicTable columns={columns} initData={initData} />
    </div>
  )
}

export default Movies
