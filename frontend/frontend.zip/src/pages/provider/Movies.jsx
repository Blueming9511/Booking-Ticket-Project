import React, { useState, useEffect } from "react";
import { Card, Space, Button, message, Input, Form } from "antd";
import {
  FilterOutlined,
  PlusOutlined,
  SearchOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import ModalMovieEdit from "../../components/MovieManagementProvider/ModalMovieEdit";
import ModalMovieAdd from "../../components/MovieManagementProvider/ModalMovieAdd";
import MovieStatistics from "../../components/MovieManagementProvider/MovieStatistics";
import MovieTable from "../../components/MovieManagementProvider/MovieTable";
import axios from "axios";
import ModalMovieDelete from "../../components/MovieManagementProvider/ModalMovieDelete";

const Movies = () => {
  const [form] = Form.useForm();
  const [messageApi, contextHolder] = message.useMessage();
  const [state, setState] = useState({
    loading: false,
    isModalEditOpen: false,
    isModalAddOpen: false,
    isModalDeleteOpen: false,
    editingMovie: null,
    deletingMovie: null,
    movies: [],
    filteredMovies: [],
    searchText: "",
  });

  const fetchMovies = async () => {
    setState((prev) => ({ ...prev, loading: true }));
    try {
      const response = await axios.get("http://localhost:8080/api/movies", {
        withCredentials: true,
      });
      setState((prev) => ({
        ...prev,
        movies: response.data,
        filteredMovies: response.data,
        loading: false,
      }));
    } catch (error) {
      messageApi.error("Failed to fetch movies");
      console.error("Error fetching movies:", error);
      setState((prev) => ({ ...prev, loading: false }));
    }
  };

  useEffect(() => {
    fetchMovies();
  }, []);

  const handleSearch = (value) => {
    setState((prev) => ({ ...prev, searchText: value }));
    if (value.trim() === "") {
      setState((prev) => ({ ...prev, filteredMovies: prev.movies }));
    } else {
      const filtered = state.movies.filter((movie) =>
        movie.title.toLowerCase().includes(value.toLowerCase())
      );
      setState((prev) => ({ ...prev, filteredMovies: filtered }));
    }
  };

  // Edit handlers
  const handleEdit = (record) => {
    setState((prev) => ({
      ...prev,
      editingMovie: record,
      isModalEditOpen: true,
    }));
    form.setFieldsValue({
      ...record,
      releaseDate: record.releaseDate ? dayjs(record.releaseDate) : null,
      endDate: record.endDate ? dayjs(record.endDate) : null,
    });
  };

  const handleEditSubmit = async (values) => {
    setState((prev) => ({ ...prev, loading: true }));
    try {
      await axios.put(
        `http://localhost:8080/api/movies/${state.editingMovie.id}`,
        values
      );
      messageApi.success("Movie updated successfully");
      fetchMovies();
      setState((prev) => ({ ...prev, isModalEditOpen: false }));
    } catch (error) {
      messageApi.error("Failed to update movie");
      console.error("Error updating movie:", error);
    } finally {
      setState((prev) => ({ ...prev, loading: false }));
    }
  };

  // Add handlers
  const handleAddSubmit = async (values) => {
    console.log("Added movie:", values);
    setState((prev) => ({ ...prev, loading: true }));
    try {
      await axios.post("http://localhost:8080/api/movies", values, {
        withCredentials: true,
      });
      messageApi.success("Movie added successfully");
      fetchMovies();
      setState((prev) => ({ ...prev, isModalAddOpen: false }));
    } catch (error) {
      messageApi.error("Failed to add movie");
      console.error("Error adding movie:", error);
    } finally {
      setState((prev) => ({ ...prev, loading: false }));
    }
  };

  // Delete handlers
  const handleDelete = (record) => {
    setState((prev) => ({
      ...prev,
      deletingMovie: record,
      isModalDeleteOpen: true,
    }));
  };

  const confirmDelete = async () => {
    console.log("Deleted movie:", state.deletingMovie);
    setState((prev) => ({ ...prev, loading: true }));
    try {
      await axios.delete(
        `http://localhost:8080/api/movies/${state.deletingMovie.id}`,
        {
          withCredentials: true,
        }
      );
      messageApi.success("Movie deleted successfully");
      fetchMovies();
      setState((prev) => ({ ...prev, isModalDeleteOpen: false }));
    } catch (error) {
      messageApi.error("Failed to delete movie");
      console.error("Error deleting movie:", error);
    } finally {
      setState((prev) => ({ ...prev, loading: false }));
    }
  };

  const handleCancel = () => {
    setState((prev) => ({
      ...prev,
      isModalEditOpen: false,
      isModalAddOpen: false,
      isModalDeleteOpen: false,
    }));
    form.resetFields();
  };

  return (
    <>
      {contextHolder}
      <Card
        title={<span className="text-xl font-bold">Movie Management</span>}
        extra={
          <Space>
            <Input
              placeholder="Search by movie title"
              value={state.searchText}
              onChange={(e) => handleSearch(e.target.value)}
              prefix={<SearchOutlined />}
              style={{ width: 200 }}
            />
            <Button icon={<FilterOutlined />}>Filter</Button>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() =>
                setState((prev) => ({ ...prev, isModalAddOpen: true }))
              }
            >
              Add new movie
            </Button>
          </Space>
        }
        variant="borderless"
        styles={{ header: { borderBottom: "none" } }}
        style={{ boxShadow: "none" }}
      >
        <MovieStatistics data={state.filteredMovies} />
        <MovieTable
          data={state.filteredMovies}
          onEdit={handleEdit}
          onDelete={handleDelete}
          loading={state.loading}
        />
      </Card>

      {/* Edit Modal */}
      <ModalMovieEdit
        visible={state.isModalEditOpen}
        onCancel={handleCancel}
        onSuccess={handleEditSubmit}
        form={form}
        initialValues={state.editingMovie}
        loading={state.loading}
      />

      {/* Add Modal */}
      <ModalMovieAdd
        visible={state.isModalAddOpen}
        onCancel={handleCancel}
        onSuccess={handleAddSubmit}
        loading={state.loading}
      />

      {/* Delete Confirmation Modal */}
      <ModalMovieDelete
        title={state.deletingMovie?.title}
        visible={state.isModalDeleteOpen}
        onSuccess={confirmDelete}
        onCancel={handleCancel}
        confirmLoading={state.loading}
      />
    </>
  );
};

export default Movies;
