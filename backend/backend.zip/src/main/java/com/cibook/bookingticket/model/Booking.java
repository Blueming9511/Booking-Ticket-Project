package com.cibook.bookingticket.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document (collection = "bookings")
public class Booking {
    @Id
    private String bookingID;
    private double totalPrice;
    private String status;
}
