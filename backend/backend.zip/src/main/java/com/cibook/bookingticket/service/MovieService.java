package com.cibook.bookingticket.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.cibook.bookingticket.model.Movie;
import com.cibook.bookingticket.repository.MovieRepository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.server.ResponseStatusException;

@Slf4j
@Service
public class MovieService {

    @Autowired
    private MovieRepository movieRepository;

    @PostConstruct
    public void checkConnection() {
        log.info("MongoDB connection active? {}", movieRepository.count() >= 0);
    }

    public List<Movie> getAllMovies() {
        try {
            List<Movie> movies = movieRepository.findAll();
            log.info("Retrieved {} movies from database", movies.size());
            return movies;
        } catch (Exception e) {
            log.error("Error retrieving all movies: {}", e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    public Movie getMovieById(@PathVariable("id") String id) {
        if (id == null || id.isEmpty()) {
            return null;
        }
        try {
            return movieRepository.findById(id).get();
        } catch (Exception e) {
            log.error("Error retrieving movie ID {}: {}", id, e.getMessage(), e);
            return null;
        }
    }

    public List<Movie> getMoviesByGenre(String genre) {
        return movieRepository.findByGenre(genre);
    }

    public Movie addMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    public Movie updateMovie(String id, Map<String, Object> updates) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());

        return movieRepository.findById(id)
                .map(existingMovie -> {
                    Movie updated = mapper.convertValue(updates, Movie.class);
                    BeanUtils.copyProperties(updated, existingMovie, "id", "dateRange");
                    return movieRepository.save(existingMovie);
                })
                .orElse(null);
    }

    public void deleteMovie(String id) {
        movieRepository.deleteById(id);
    }
}
