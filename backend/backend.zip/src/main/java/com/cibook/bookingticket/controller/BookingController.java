package com.cibook.bookingticket.controller;

public class BookingController {
}
