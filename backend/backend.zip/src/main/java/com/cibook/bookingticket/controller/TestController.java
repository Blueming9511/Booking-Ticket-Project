package com.cibook.bookingticket.controller;

import com.cibook.bookingticket.model.Cinema;
import com.cibook.bookingticket.repository.CinemaRepository;
import com.cibook.bookingticket.service.CinemaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/test")
public class TestController {

    @Autowired
    private MongoTemplate mongoTemplate;
    private CinemaRepository cinemaRepository;
    @Autowired
    private CinemaService cinemaService;

    @GetMapping("/connection")
    public String testConnection() {
        try {
            long count = mongoTemplate.getCollection("movies").countDocuments();
            return "Kết nối Atlas thành công! Số movies: " + count;
        } catch (Exception e) {
            return "Lỗi kết nối Atlas: " + e.getMessage();
        }
    }
}
