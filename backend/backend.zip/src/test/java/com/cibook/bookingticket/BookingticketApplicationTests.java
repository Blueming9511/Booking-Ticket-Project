package com.cibook.bookingticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingticketApplicationTests {

	@Test
	void contextLoads() {
	}

}
